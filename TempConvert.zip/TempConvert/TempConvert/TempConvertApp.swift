//
//  TempConvertApp.swift
//  TempConvert
//
//  Created by Austin Bond on 6/7/24.
//

import SwiftUI

@main
struct TempConvertApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
